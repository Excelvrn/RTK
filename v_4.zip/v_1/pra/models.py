from django.db import models

# Create your models here.

from django.conf import settings
from django.db import models
from django.utils import timezone
import django.core.validators as dcv


class pra_User(models.Model):
    id_user = models.AutoField(primary_key=True)
    login = models.CharField(max_length=100)
    passwd = models.CharField(max_length=100)
    def __str__(self):
        #return self.title
        return self.login, self.passwd

class pra_faces(models.Model):
    id_face = models.AutoField(primary_key=True)
    org_name = models.CharField(max_length=100)
    type_pf = 'PF'
    type_jf = 'JF'
    type_f = ((type_pf, 'Physic'), (type_jf, 'Jur'))
    #name = models.CharField(max_length=60)
    face_type = models.CharField(max_length=2, choices=type_f)
    #def publish(self):
        ##self.published_date = timezone.now()
        #self.save()
    def __str__(self):
        return self.id_face, self.org_name, self.face_type

class guser(models.Model):
    id_user = models.AutoField(primary_key=True)
    login = models.CharField(max_length=100)
    passwd = models.CharField(max_length=100)
    def __str__(self):
        #return self.title
        return self.login, self.passwd

class sessions(models.Model):
    id_user = models.AutoField(primary_key=True)
    sessionid= models.CharField(max_length=100)
    dt = models.DateTimeField(auto_now=False, auto_now_add=True)
    def __str__(self):
        #return self.title
        return self.id_user, self.sessionid, self.dt

#worked users
class worked_users(models.Model):
    id_user = models.AutoField(primary_key=True)
    user_email= models.CharField(max_length=100)
    passwd = models.CharField(max_length=100)
    dt = models.DateTimeField(auto_now=False, auto_now_add=True)
    country = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    ogrn =  models.CharField(max_length=30)
    def __str__(self):
        #return self.title
        return self.id_user,self.user_email, self.passwd, self.dt, self.country, self.city, self.ogrn

#################################################
####### for ROSTELECOM-test
#######     F R O M
#################################################
class VL(models.Model):
    id_VL = models.AutoField(primary_key=True)
    priority = models.IntegerField()
    usl = models.IntegerField()
    def __str__(self):
        #return self.title
        return self.id_VL,self.priority, self.usl
class TT(models.Model):
    id_TT = models.AutoField(primary_key=True)
    dt_start = models.DateTimeField(auto_now=True, auto_now_add=False)
    dt_stop = models.DateTimeField(auto_now=False, auto_now_add=True)
    text = models.CharField(max_length=30)
    vl = models.ForeignKey('VL', on_delete=models.CASCADE)
    def __str__(self):
        #return self.title
        #return self.id_TT,self.dt_start, self.dt_start,self.text, self.vl
        return self.id_TT,self.dt_start, self.dt_start,self.text
#################################################
####### for ROSTELECOM-test
#######     T O
#################################################

