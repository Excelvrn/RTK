from django.urls import path

from django.conf.urls import url

from pra.viewsd import login, createuser

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    #path('add/', views.index2, name='index2'),
    #path('form1/', views.index3, name='index3'),
    #path('form2/', views.index4, name='index4'),
    path('get_name/', views.get_name, name='get_name'),
    #path('get_name_2/', views.get_name_2, name='get_name_2'),
    #path('get_name_3/', views.get_name_3, name='get_name_3'),
    #path('get_name_4/', views.get_name_4, name='get_name_4'),
    #path('main_index/', views.main_index, name='main_index'),
    path('get_name_5/', views.get_name_5, name='get_name_5'),
    path('registrate/', views.registrate, name='registrate'),
    #path('registrate2/', views.registrate2, name='registrate2'),
    url('login/', login.user_login, name='login'),
    url('createuser/', createuser.createuser, name='createuser'),
    path('perepiska/', views.perepiska, name='perepiska'),
    path('test1/', views.test1, name='test1'),
    path('test2/', views.test2, name='test2'),
    path('test3/', views.test3, name='test3'),
    path('test4/', views.test4, name='test4'),
]



#for el in urlpatterns:
    #print(el)
#for urlp in urlpatterns:
    #print("\t***\turlp:\t", urlp)
