from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from pra.forms import login

from django.contrib.auth.models import User
#user = User.objects.create_user(username='john',
#...                                 email='jlennon@beatles.com',
#...                                 password='glass onion')

def createuser(request):
    if request.method == 'POST':
        print(request.POST)
        ddd = login(request.POST)
        if ddd.is_valid():
            user = User.objects.create_user(username=request.POST['login'],\
                email=request.POST['email'],\
                password=request.POST['passwd'])
    else:
        ddd = login()
    l = User.objects.all()
    print(type(l))
    for el in l:
        print(el.username)
    return render(request, 'reg.3.html', {'form': ddd})
