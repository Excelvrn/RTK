from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from pra.forms import NameForm

def user_login(request):
    if request.method == 'POST':
        print(request.POST)
        form = NameForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(username=cd['your_name'], password=cd['your_passwd'])
            #user = authenticate(username=cd['login'], password=cd['passwd'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    print('\tAuthenticated successfully')
                    return HttpResponse('Authenticated successfully')
                else:
                    print('\tDisabled account')
                    return HttpResponse('Disabled account')
            else:
                print('\tInvalid login')
                return HttpResponse('Invalid login')
        else:
            print("\t***\tform isn`t valid")
    else:
        form = NameForm()
    return render(request, 'reg.2.html', {'form': form})
