print("\trun index1.py")

from django.shortcuts import render
from django.http import HttpResponseRedirect


#from django.core.context_processors import csrf

# Create your views here.

from django.http import HttpResponse
#from .models import pra_User
#from .models import guser
from pra.models import sessions
#from .models import worked_users

def getdatas(request):
    obj_sessionid = sessions()
    obj_sessionid.sessionid = request.COOKIES['csrftoken']
    obj_sessionid.save()
    g = sessions.objects.order_by('sessionid')
def Request(request):
    print(f"\t***\tRequest:\t{type(request)}")
    print(request.session)
    #print("\tUser:\t", request.user)

