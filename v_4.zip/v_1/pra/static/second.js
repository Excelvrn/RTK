
//<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
//  		<script >
            function rp(a){
                //document.location.replace("http://80.82.63.117");
                //document.location.replace("http://yandex.ru");
                console.log(a);
                var d1 = document.getElementById(a);
                //console.log(type(d1));
                
            }
            
              
            function delete_indextext() { 
                var indextext = document.getElementById('afterdel'); 
                indextext.remove();
                console.log("asdfasdf");
            }  
            
            function onloadf1(){
                //console.log(i.toString());
               // var base = document.createElement("div");
                //document.body.appendChild(base);
               /* for (i = 1; i<10; i++){
                    var d1 = document.createElement("div");
                    if (id_index==1)
                        d1.innerHTML = "start" + i.toString();
                    else 
                        d1.innerHTML = "div" + i.toString();
                    d1.id = "id" + i.toString();
                    document.body.appendChild(d1);
                }
                */for (id_index; id_index<10; id_index++){
                    var d1 = document.createElement("div");
                    if (id_index==1)
                        d1.innerHTML = "start" + id_index.toString();
                    else 
                        d1.innerHTML = "div" + id_index.toString();
                    d1.id = "id" + id_index.toString();
                    document.body.appendChild(d1);
                    
                }
                for (id_index; id_index<20; id_index++){
                    var d1 = document.createElement("div");
                    if (id_index==1)
                        d1.innerHTML = "start" + id_index.toString();
                    else 
                        d1.innerHTML = "div" + id_index.toString();
                    d1.id = "id" + id_index.toString();
                    document.body.appendChild(d1);
                }
                delete_indextext();
//                 var d1 = document.createElement("div");
//                 let number = 1;
//                 d1.innerHTML = "div" + number.toString();
//                 document.body.appendChild(d1);
//                 var d1 = document.getElementById('indextext');
//                 d1.insertAdjacentHTML('afterend', '<div id="two">two</div>');
//                 document.body.appendChild("div");
//                 
                //console.log(sd);
                //console.log(document.body);
            }
            function    bl(){
                //window.alert("DFDASSDF");
                window.blur();
            }
            function    change_url_1(){
                document.location.replace("/two.html");
            }

    function send(){
        var xhr = new XMLHttpRequest();
        xhr.open("POST", '/server', true);

        //Send the proper header information along with the request
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function() { // Call a function when the state changes.
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            // Request finished. Do processing here.
        }
    }
    xhr.send("foo=bar&lorem=ipsum");
    // xhr.send(new Int8Array());
    // xhr.send(document);

    }
