from django import forms

class NameForm(forms.Form):
    your_name = forms.CharField(label='login', max_length=100)
    your_passwd = forms.CharField(label='passwd', max_length=100)

class login(forms.Form):
    login = forms.CharField(label='login', max_length=100)
    passwd = forms.CharField(label='login', max_length=100)
    email = forms.CharField(label='login', max_length=100)
    
class worked_users(forms.Form):
    #id_user = forms.AutoField(primary_key=True)
    user_email= forms.CharField(label='user_email',max_length=100)
    passwd = forms.CharField(label='passwd',max_length=100)
    #dt = forms.DateTimeField(auto_now=False, auto_now_add=True)
    country = forms.CharField(label='country',max_length=30)
    city = forms.CharField(label='city',max_length=30)
    ogrn =  forms.CharField(label='ogrn',max_length=30)
#################################################
####### for ROSTELECOM-test
#######     F R O M
#################################################
class VL(forms.Form):
    priority = forms.IntegerField()
    usl = forms.IntegerField()
class TT(forms.Form):
    #dt_start = forms.DateTimeField(auto_now=False, auto_now_add=True)
    #dt_start = forms.DateTimeField(auto_now=False, auto_now_add=True)
    text = forms.CharField(max_length=30)
    vl =  forms.CharField(max_length=30)
#################################################
####### for ROSTELECOM-test
#######     T O
#################################################
