print("\tload f1.py")

paths = ["/pra", "/pra/add/"]


s = lambda path: f'<a href={path}>{path}</a><br>'

def insert_paths(lp):
    k = ""
    for el in paths:
        k+=s(el)
        
