print("\tload f1.py\n")

paths = ["/pra",\
        #"/pra/add/",\
        #"/pra/form1/",\
        #"/pra/form2/",\
        "/pra/get_name/",\
        #"/pra/get_name_2/",\
        #"/pra/get_name_3/",\
        #"/pra/get_name_4/",\
        #"/pra/main_index/"\
        "/pra/get_name_5/",\
        "/pra/registrate/",\
        #"/pra/registrate2/"
        "/pra/login/",\
        "/pra/createuser/",\
        "/pra/perepiska/",\
        "/pra/test1/",\
        "/pra/test2/",\
        "/pra/test3/",\
        "/pra/test4/",
        ]


s = lambda path: f'<a href={path}>{path}</a><br>'

def insert_paths(lp):
    k = ""
    for el in paths:
        k+=s(el)
    print("\t\t***\tinsert_paths", k)
    return k

from django.conf import settings
settings.SESSION_COOKIE_AGE = 300
print("***\tSESSION_COOKIE_AGE:\t",settings.SESSION_COOKIE_AGE) 
print("***\SESSION_ENGINE:\t",settings.SESSION_ENGINE) 

#print(settings.DEBUG)
##settings.DEBUG = False
#print(settings.SESSION_COOKIE_NAME)
#print("\t***\tSESSION_ENGINE:\t", settings.SESSION_ENGINE)
#print(settings.DEBUG)
