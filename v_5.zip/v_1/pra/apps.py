from django.apps import AppConfig


class PraConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pra'
