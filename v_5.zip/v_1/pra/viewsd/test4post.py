import datetime as dt
def datepost(request):
    print("\t***\trequest.GET", request.GET)
    dd = 0
    mm = 0
    yyyy = 0
    dtar = []
    for el in request.GET:
        print('\t\t', el, request.GET[el])
        print('\t\t', request.GET[el].split('-'))
        g = request.GET[el].split('-')
        yyyy = int(g[0])
        mm = int(g[1])
        dd = int(g[2])
        dtobj = dt.datetime(yyyy, mm, dd, tzinfo = dt.timezone(dt.timedelta(hours=0)))
        dtar+=[dtobj]
    print(dtar)
    return dtar[0], dtar[1]
        
