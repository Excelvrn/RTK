#from django.contrib import admin

# Register your models here.

from django.contrib import admin
from .models import pra_User, pra_faces, guser,sessions, worked_users, \
    TT, VL

admin.site.register(pra_User)
admin.site.register(pra_faces)
admin.site.register(guser)
admin.site.register(sessions)
admin.site.register(worked_users)
admin.site.register(TT)
admin.site.register(VL)
