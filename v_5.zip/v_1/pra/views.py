from django.shortcuts import render
from django.http import HttpResponseRedirect

from django.contrib import auth

import pra.viewsd.index1 as pvi1

import math



#from django.core.context_processors import csrf

# Create your views here.

from django.http import HttpResponse
from .models import pra_User
from .models import guser
from .models import sessions
from .models import worked_users as w_u

def main_index(request):
    #lll = "asdf"
    #num_books=pra_User.objects.all().count()
    #lll = str(num_books)
    #lll = pra_User.objects.all()
    lll = pra_User.objects.order_by('login')
    print(type(lll))
    #for k in lll:
        #print(k)
    #num_instances=BookInstance.objects.all().count()
    return render(request, 'pra/pra_user_template.html', context={'lll':lll})

import mod_v_1.f2 as mv1f2
def index(request):
    #pvi1.getdatas(request)
    #pvi1.Request(request)
    #print(s("/pra/") + s("/pra/add/") )
    #ls = s("/pra/") + s("/pra/add/")
    #print(s("/pra/add/"))
    print(index)
    #print("\t***\trequest.COOKIES:\t", request.COOKIES)
    #print("\t***\trequest.POST:\t", request.POST)
    #print("index", "\tGET==",request.method=="GET")
    #print("\tSession:\t", request.session, len(request.session), sep='\t')
    #print("\tSession:\t", request.session, sep='\t')
    #for el in request.session:
        #print(el)
    #
    # request.session.keys()
    #
    #print(request.session.keys())
    #for el in request.session.keys():
    #    print(el, ":\t",request.session[el])
    #print("session:\t", request.session, type(request.session))
    #print("session:\t", request.session)
    #print("HttpRequest.META:\t", request.META)
    #for el in request.session:
        #print("\t***\tRequest\t", el, request.session[el])

    #for el in request.META:
        ##if request.META[el].find("ses"):
        ##print("\t***\tRequest.META:\t", el, request.GET[el], type(request.GET[el]))
        #print("\t***\tRequest.META:\t", el)
        
    #for el in request.POST:
        #print("\t***\tRequest.POST:\t", el, type(el))
        
    #print("request.COOKIES['sessionid']:\n",request.COOKIES['sessionid'], type(request.COOKIES), sep = '\t\t')
    #print("session:\t", request.session['login'])
    #if request.method=='POST':
        #print('\tsession:\t', request.session['login'],'\nend session')
    #return HttpResponse("Hello, world. You're at the polls index.<br><br><br><br><a href='/pra/form1'> form1  </a>")
    #ans = mv1f2.insert_paths(mv1f2.paths) + "<div>"+request.COOKIES['sessionid']+"</div>"+\
            #"<div>"+request.COOKIES['csrftoken']+"</div>"
    ans = mv1f2.insert_paths(mv1f2.paths) + \
            "<div>"+request.COOKIES['csrftoken']+"("+str(len(request.COOKIES['csrftoken']))+" bytes)"+"</div>"
    #obj_sessionid = sessions()
    #obj_sessionid.sessionid = request.COOKIES['csrftoken']
    #obj_sessionid.save()
    #g = sessions.objects.order_by('sessionid')
    #for el in g:
        #print('\t', el.sessionid, el.dt)
    #return HttpResponse(mv1f2.insert_paths(mv1f2.paths))
    return HttpResponse(ans)
    
    #return render(request, 'pra/name.html', {})

def index2(request):
    print("index2")
    if request.method=="GET":
	    print("index2\tGET")
    return HttpResponse("<a href='/pra'> index2<br>admin </a>")	
    #return HttpResponse("index2")	
    
def index3(request):
    print("index3")
    if request.method=="GET":
        print("index3\tGET")
    if request.method=="POST":
        print("index3\tPOST")
    return HttpResponse("<a href='/pra'> index2<br>admin </a>" + '<form action="/pra/get_name/" method="post">'+\
    '<label for="your_name">Your name: </label>'+\
    '<input id="your_name" type="text" name="your_name" value="{{ current_name }}">'+\
    '<input type="submit" value="OK">'+\
    '</form>')
    
def index4(request):
    print("index4")
    if request.method=="GET":
        print("\t***\tGET")
    else:
        print("\t***\tPOST")
        return render(request, None, {'form': form})
    return HttpResponse("<a href='/pra'> index4<br>admin </a>")
    
    
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .forms import NameForm
from .forms import login, worked_users
var_get_name=3
if var_get_name == 1:
    '''
	def get_name(request):
		# if this is a POST request we need to process the form data
		print("get_name\trun")
		if request.method == 'POST':
			print("get_name\tcondition")
			# create a form instance and populate it with data from the request:
			form = NameForm(request.POST)
			# check whether it's valid:
			if form.is_valid():
				# process the data in form.cleaned_data as required
				# ...
				# redirect to a new URL:
				return HttpResponseRedirect('pra/')

		# if a GET (or any other method) we'll create a blank form
		else:
			form = NameForm()

        return render(request, 'name.html', {'form': form})
    '''
elif var_get_name == 2:
    def get_name(request):
        print("\t***\trequest.COOKIES:\t", request.COOKIES)
        #return render(request, 'pra/post_list.html', {})
        #return render(request, 'pra/name.html', {})
        if request.method == 'POST':
            print("\t***\tget_name\tcondition")
            print("\t***\trequest.POST:\t", request.POST['your_name'], request.POST['your_passwd'])
            #print(request.__doc__)
            # create a form instance and populate it with data from the request:
            form = NameForm(request.POST)
            # check whether it's valid:
            if form.is_valid():
                g = pra_User()
                #g.id_user = None
                #id_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
                #login = models.CharField(max_length=30)
                g.login = request.POST['your_name']
                #g.id_user = 100
                g.passwd = request.POST['your_passwd']
                g.save()
                # process the data in form.cleaned_data as required
                # ...
                # redirect to a new URL:
                return HttpResponseRedirect('/pra/get_name_2')

        # if a GET (or any other method) we'll create a blank form
        else:
            form = NameForm()
        return render(request, 'name.html', {'form': form, 'g': str(333)})
elif var_get_name == 3:
    def get_name(request):
        print("\t***\trequest.COOKIES:\t", request.COOKIES)
        #return render(request, 'pra/post_list.html', {})
        #return render(request, 'pra/name.html', {})
        if request.method == 'POST':
            print("\t***\tget_name\tcondition")
            print("\t***\trequest.POST:\t", request.POST['your_name'], request.POST['your_passwd'])
            for el in request.POST:
                print("\t***\tRequest.POST:\t", el, type(el), "\n", request.POST[el], type(el))
            #print(request.__doc__)
            # create a form instance and populate it with data from the request:
            form = NameForm(request.POST)
            # check whether it's valid:
            if form.is_valid():
                g = guser()
                #g.id_user = None
                #id_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
                #login = models.CharField(max_length=30)
                g.login = request.POST['your_name']
                #g.id_user = 100
                g.passwd = request.POST['your_passwd']
                g.save()
                # process the data in form.cleaned_data as required
                # ...
                # redirect to a new URL:
                return HttpResponseRedirect('/pra/get_name/')
            # if a GET (or any other method) we'll create a blank form
        else:
            form = NameForm()
            print(get_name.__name__)
            return render(request, 'name.html', {'form': form})
def get_name_2(request):
    if request.method == 'POST':
        #s = request.session['your_name']
        #print("request.session['your_name']:\t",request.session['your_name'])
        print("get_name\tcondition")
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            g = pra_User()
            #id_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
            #login = models.CharField(max_length=30)
            g.id_user = "nu_id_user"
            g.login = "nu_id_user"
            g.save()
            return HttpResponseRedirect('/pra/get_name')
        

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()
    return render(request, 'name.html', {'form': form})
def get_name_3(request):
    if request.method == 'POST':
        #s = request.session['your_name']
        #print("request.session['your_name']:\t",request.session['your_name'])
        print("get_name_3\tcondition")
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/pra/get_name')

    # if a GET (or any other method) we'll create a blank form
    else:
        form = login()
    return render(request, 'login.html', {'form': form})

def get_name_4(request):
    if request.method == 'POST':
        #s = request.session['your_name']
        #print("request.session['your_name']:\t",request.session['your_name'])
        print("get_name_3\tcondition")
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/pra/get_name')

    # if a GET (or any other method) we'll create a blank form
    else:
        form = login()
    return render(request, 'login.html', {'form': form})

def get_name_5(request):
    start = 0
    if request.method=="GET":
        print("\t***get_name_5\n\tget!!!")
        print("\t\t", type(request.GET))
        for rg in request.GET:
            print("\t\trg:\t", rg)
            print(type(int(rg)))
            start = int(rg)
    if request.method=="POST":
        print("\tPOST:\t", request.POST)
        k = 0
        iel = 0
        for el in request.POST.keys():
            #print('\t', el)
            if k==1:
                #print("\t***\tel:\t", )
                print("***\tsplit:\t", el.split('_')[1])
                print('***\tname:\t',request.POST[el])
                start = int(el.split('_')[1])
                
                iel = start
                
                qdict = sessions.objects.get(id_user=iel)
                qdict.sessionid = request.POST[el]
                qdict.save()
                #print("***\ttype(qdict):\t", type(qdict))
                #g.sessionid = request.POST[el]
                #g.save
                start = math.floor(start/10)*10
                print("***\tstart:\t", start)
            k+=1
        #print("***\trequest.POST.pop(name)\t", 
#request.POST.keys(), type(request.POST.keys()))
        print(request.POST)
        
    
    obj_sessionid = sessions()
    obj_sessionid.sessionid = request.COOKIES['csrftoken']
    obj_sessionid.save()
    #g = sessions.objects.order_by('sessionid')
    g = sessions.objects.all()
    #lg = sessions.objects.get(id_user<10)
    
    print("\t***g:\t",len(g), type(g))
    """
    id_user = models.AutoField(primary_key=True)
    sessionid= models.CharField(max_length=100)
    dt = models
    """
    gm = []
    end = 0
    if len(g)>=(start+10):
        end = start+10
    else:
        end = len(g)
    print("\t", start, "-", end)
    for i in range(start, end):
        gm+=[g[i]]
        
    #k = 0
    #while (k<10):
        ##for el in g:
        #el = g[k]
        #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
        #k+=1
    #el = g[10]
    #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
    k=[]
    for i in range(0, len(g),10):
        k+=[str(i)]
    
    return render(request, 'example.html', {'l':gm , 'm':k})

def registrate(request):
    print("\t***\tregistrate")
    print('\t***\t', request.method)
    if request.method == 'POST':
        #s = request.session['your_name']
        #print("request.session['your_name']:\t",request.session['your_name'])
        print("request.POST:\t", request.POST)
        print("registrate\tcondition")
        # create a form instance and populate it with data from the request:
        form = worked_users(request.POST)
        print(type(form))
        print('\t\t***')
        # check whether it's valid:
        if form.is_valid():
            k = w_u()
            k.user_email = request.POST['user_email']
            k.passwd = request.POST['passwd']
            k.country = request.POST['country']
            k.city = request.POST['city']
            k.ogrn = request.POST['ogrn']
            k.save()
            """
                id_user = models.AutoField(primary_key=True)
                user_email= models.CharField(max_length=100)
    passwd = models.CharField(max_length=100)
    dt = models.DateTimeField(auto_now=False, auto_now_add=True)
    country = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    ogrn =  models.CharField(max_length=30)
            """
            form.user_email = request.POST['passwd']
            print('\tform["passwd"]:\t', form.user_email )
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/pra/registrate/')
    # if a GET (or any other method) we'll create a blank form
    else:
        form = worked_users()
        #print(type(form))
    return render(request, 'reg.1.html', {'form': form})
    #return render(request, 'reg.1.html')
def registrate2(request):
    #print("\t***\tregistrate2")
    #print("\t***\t", request.user)
    #return HttpResponse("asdf")
    username = request.POST['username']
    password = request.POST['password']
    user = auth.authenticate(username=username, password=password)
    if user is not None and user.is_active:
        # Правильный пароль и пользователь "активен"
        auth.login(request, user)
        # Перенаправление на "правильную" страницу
        return HttpResponse("right")
    else:
        # Отображение страницы с ошибкой
        #return HttpResponseRedirect("/account/invalid/")
        return HttpResponse("false")



def perepiska(request):
    #print(os.getcwd().split('/'))
    return render(request, 'messages.html')

#################################################
####### for ROSTELECOM-test
#######     F R O M
#################################################
from .models import VL as VLm
from .forms import VL as VLf
from .models import TT as TTm
from .forms import TT as TTf

import pra.viewsd.test4post as pvt

def test1(request):
    #print("\t***\trequest.COOKIES:\t", request.COOKIES)
    #return render(request, 'pra/post_list.html', {})
    #return render(request, 'pra/name.html', {})
    if request.method == 'POST':
        print("\t***\ttest\tcondition")
        print("\t***\trequest.POST:\t", request.POST['priority'], request.POST['usl'])
        for el in request.POST:
            print("\t***\tRequest.POST:\t", el, type(el), "\n", request.POST[el], type(el))
        #print(request.__doc__)
        # create a form instance and populate it with data from the request:
        form = VLf(request.POST)
        # check whether it's valid:
        if form.is_valid():
            g = VLm()
            #g.id_user = None
            #id_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
            #login = models.CharField(max_length=30)
            g.priority = request.POST['priority']
            #g.id_user = 100
            g.usl = request.POST['usl']
            g.save()
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/pra/test1/')
        # if a GET (or any other method) we'll create a blank form
    else:
        form = VLf()
        print(get_name.__name__)
        return render(request, 'test1.html', {'form': form})
def test2(request):
    print("\n\t===============================")
    #print("\t***\trequest.COOKIES:\t", request.COOKIES)
    #return render(request, 'pra/post_list.html', {})
    #return render(request, 'pra/name.html', {})
    if request.method == 'POST':
        print("\t***\ttest\tcondition")
        #print("\t***\trequest.POST:\t", request.POST['text'], request.POST['vl'])
        #print("***\t", request.POST)
        for el in request.POST:
            #print("\t***\tRequest.POST:\t", el, type(el), "\n", request.POST[el], type(el))
            print("\t***\tRequest.POST:\t", el, "---", request.POST[el])
            #print("\t***\tRequest.POST:\t", el)
        #print(request.__doc__)
        # create a form instance and populate it with data from the request:
        form = TTf(request.POST)
        # check whether it's valid:
        if form.is_valid():
            g = TTm()
            #g.id_user = None
            #id_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
            #login = models.CharField(max_length=30)
            g.text = request.POST['text']
            #g.id_user = 100
            ind = int(request.POST['vl'])
            print("\tind:\t", ind)
            vlobj = VLm.objects.all()[int(request.POST['vl'])-1]
            #print(vlobj.priority)
            g.vl = vlobj
            g.save()
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/pra/test2/')
        # if a GET (or any other method) we'll create a blank form
    else:
        form = TTf()
        vls = VLm.objects.all()
        return render(request, 'test2.html', {'form': form, 'vl_all':vls})
def test3(request):
    print("\t============== t e s t - 3 ==============")
    start = 0
    if request.method=="GET":
        print("\t***test-3\n\tget!!!")
        print("\t\t", type(request.GET))
        for rg in request.GET:
            print("\t\trg:\t", rg)
            print(type(int(rg)))
            start = int(rg)
    if request.method=="POST":
        print("\tPOST:\t", request.POST)
        k = 0
        iel = 0
        for el in request.POST.keys():
            print('\t', el)
            if k==1:
                #print("\t***\tel:\t", )
                print("***\tsplit:\t", el.split('_')[1])
                print('***\ttext:\t',request.POST[el])
                start = int(el.split('_')[1])
                
                iel = start
                
                qdict = TTm.objects.get(id_TT=iel)
                qdict.text = request.POST[el]
                qdict.save()
                #print("***\ttype(qdict):\t", type(qdict))
                #g.sessionid = request.POST[el]
                #g.save
                start = math.floor(start/10)*10
                print("***\tstart:\t", start)
            k+=1
        #print("***\trequest.POST.pop(name)\t", 
#request.POST.keys(), type(request.POST.keys()))
        print(request.POST)
        
    # TTm
    #obj_sessionid = sessions()
    #obj_sessionid.sessionid = request.COOKIES['csrftoken']
    #obj_sessionid.save()
    #g = sessions.objects.order_by('sessionid')
    g = TTm.objects.all()
    #lg = sessions.objects.get(id_user<10)
    
    print("\t***g:\t",len(g), type(g))
    """
    id_user = models.AutoField(primary_key=True)
    sessionid= models.CharField(max_length=100)
    dt = models
    """
    gm = []
    end = 0
    if len(g)>=(start+10):
        end = start+10
    else:
        end = len(g)
    print("\t", start, "-", end)
    for i in range(start, end):
        gm+=[g[i]]
        
    #k = 0
    #while (k<10):
        ##for el in g:
        #el = g[k]
        #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
        #k+=1
    #el = g[10]
    #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
    k=[]
    for i in range(0, len(g),10):
        k+=[str(i)]
    
    return render(request, 'test3.html', {'l':gm , 'm':k})
def test4(request):
    print("\t============== t e s t - 4 ==============")
    start = 0
    g = TTm.objects.all()
    if request.method=="GET":
        #start_date, end_date = pvt.datepost(request)
        print("\t***test-4\n\tget!!!")
        print("\t\t", type(request.GET))
        
        ind_date = 0
        for el in request.GET.keys():
            print('\tget-keys:\t', el,request.GET[el] )
            if el=="datefrom" or el=="dateto":
                ind_date+=1
                print(ind_date, request.GET[el])
            #start_date, end_date = pvt.test4post.datepost(request)
            #gf = TTm.objects.filter(dt_start__range=(start_date, end_date))
            #print("\tgf-size:\t", gf.count())
        #for rg in request.GET:
            #print("\t\trg:\t", rg)
            ##start = int(rg)
        if ind_date == 2:
            start_date, end_date = pvt.datepost(request)
            gf = TTm.objects.filter(dt_start__range=(start_date, end_date))
            print("\tgf-size:\t", gf.count())
            if gf.count() > 0:
                g = gf
            
    if request.method=="POST":
        print("\tPOST:\t", request.POST)
        k = 0
        iel = 0
        for el in request.POST.keys():
            print('\tkeys:\t', el)
        for el in request.POST.keys():
            print('\t', el)
            if k==1:
                pass
                ##print("\t***\tel:\t", )
                #print("***\tsplit:\t", el.split('_')[1])
                #print('***\ttext:\t',request.POST[el])
                #start = int(el.split('_')[1])
                
                #iel = start
                
                #qdict = TTm.objects.get(id_TT=iel)
                #qdict.text = request.POST[el]
                #qdict.save()
                ##print("***\ttype(qdict):\t", type(qdict))
                ##g.sessionid = request.POST[el]
                ##g.save
                #start = math.floor(start/10)*10
                #print("***\tstart:\t", start)
            k+=1
        #print("***\trequest.POST.pop(name)\t", 
        #request.POST.keys(), type(request.POST.keys()))
        #print(request.POST)
        
    # TTm
    #obj_sessionid = sessions()
    #obj_sessionid.sessionid = request.COOKIES['csrftoken']
    #obj_sessionid.save()
    #g = sessions.objects.order_by('sessionid')
    #g = TTm.objects.all()
    
    # dt_start!!!
    #start_date, end_date = pvt.test4post.datepost(request)
    #gf = TTm.objects.filter(dt_start__range=(start_date, end_date))
    #print("\tgf-size:\t", gf.count())
    
    #lg = sessions.objects.get(id_user<10)
    
    print("\t***g:\t",len(g), type(g))
    """
    id_user = models.AutoField(primary_key=True)
    sessionid= models.CharField(max_length=100)
    dt = models
    """
    gm = []
    end = 0
    if len(g)>=(start+10):
        end = start+10
    else:
        end = len(g)
    print("\t", start, "-", end)
    for i in range(start, end):
        gm+=[g[i]]
        
    #k = 0
    #while (k<10):
        ##for el in g:
        #el = g[k]
        #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
        #k+=1
    #el = g[10]
    #print("\t***lg:\t",el.id_user,el.sessionid,  el.dt)
    k=[]
    for i in range(0, len(g),10):
        k+=[str(i)]
    #pvt.datepost(request)
    return render(request, 'test4.html', {'l':gm , 'm':k})
#################################################
####### for ROSTELECOM-test
#######     T O
#################################################

